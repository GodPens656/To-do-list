import asyncio
import flet as ft
from .controls import SurfaceHost
from datetime import datetime
from .theme import get_theme_colors
from .libs import Fr_Libs
from .attachments import attachment_controls
from Backend.extended import Backend2
from Backend.core import local_today

from threading import Thread
import threading


class Utils:
    def __init__(
        self,
        cloud,
        back,
        theme,
        page=None,
        web_store=None,
        icon_pack="minimalistic",
        button_color=None,
    ):
        """Импорт """
        self.back = back
        # page/web_store прокинуты из Front, чтобы на сайте этот Backend2
        # писал настройки в тот же браузерный store, что и основной
        # self.back2 во Front, а не в отдельные файлы на сервере.
        self.back2 = Backend2(page=page, web_store=web_store, back=back, cloud=cloud)
        self.theme = theme

        self.phone = self.back.get_device()
        self.libs = Fr_Libs(
            self.theme,
            self.phone,
            page=page,
            web=web_store is not None,
            icon_pack=icon_pack,
            button_color=button_color,
        )


        self.font = int()
        self.width_dialogs = int()
        self.height_dialogs = int()
        self.padding = int()
        self.padding_for_row = int()
        self.height_for_dlg_spacer = int()

        self.colors = get_theme_colors(self.theme, button_color)
        self.BorderColor = self.colors["BorderColor"]
        self.ContBgColor = self.colors["ContBgColor"]
        self.BgColor = self.colors["BgColor"]
        self.TxtColor = self.colors["TxtColor"]
        self.BtnColor = self.colors["BtnColor"]

        """Настройки отступов и т.д."""
        if self.phone:
            self.font = 14
            self.height_dialogs = 300
            self.width_dialogs = self.libs.width_dialogs
            self.padding = 10
            self.padding_for_row = 0
            self.height_for_dlg_spacer = 20
        else:
            self.font = 16
            self.height_dialogs = 500
            self.width_dialogs = 550
            self.padding = 20
            self.padding_for_row = 10
            self.height_for_dlg_spacer = 0
        self.btn_new_task = ft.Button()
        self.cloud = cloud

    def create_row_with_task(self, task, status, id_task, created_date=None, group_id='default',
                             deadline=None, priority='Неважно', info_type='created_date',
                             *, show_checkbox=True, group_settings=None, attachments=None,
                             on_copy=None, on_repeat=None):
        """Функция для создания и возвращения строки с делом, кнопками и т.д.
        created_date — дата создания дела (ДД-ММ-ГГГГ), отображается
        мелкой подписью под названием дела, если известна и если включена
        настройка "Подписывать дату создания дел" для группы group_id,
        которой принадлежит дело (настройка хранится у самой группы в
        itog.json, а не в общем settings.txt). Для заметок show_checkbox=False
        создаёт такую же карточку без элемента отметки выполнения."""
        taskW = self.libs.linked_text(
            f"{task}",
            no_wrap=False,
            size=self.libs.text_size(self.font),
            color=self.TxtColor,
            weight=ft.FontWeight.W_500,
            style=ft.TextStyle(decoration=ft.TextDecoration.LINE_THROUGH)
            if status
            else None,
        )

        if group_settings is None:
            group_settings = self.back.get_group_settings(group_id or 'default')
        show_created_date = group_settings["show_created_date"]

        details = []
        # При выборе дедлайна или важности показываем только выбранную
        # дополнительную информацию, без даты создания.
        if created_date and show_created_date and info_type == "created_date":
            details.append(ft.Text(
                f"Создано: {created_date}",
                size=self.libs.text_size(12),
                color=self.colors["MutedColor"],
            ))
        if info_type == "deadline" and deadline:
            deadline_color = ft.Colors.with_opacity(0.75, self.TxtColor)
            try:
                days_left = (
                    datetime.strptime(deadline, "%d-%m-%Y").date()
                    - local_today(self.back.web, self.back.page)
                ).days
                if days_left <= 1:
                    deadline_color = self.colors["DangerColor"]
                elif days_left <= 2:
                    deadline_color = self.colors["WarnTextColor"]
                elif days_left <= 3:
                    deadline_color = self.colors["SuccessColor"]
            except (TypeError, ValueError):
                pass
            details.append(self._task_badge(
                ft.Icons.SCHEDULE_ROUNDED, f"До {deadline}", deadline_color,
            ))
        if info_type == "priority":
            priority_color = {
                "Неважно": self.colors["SuccessColor"],
                "Важно": self.colors["WarnTextColor"],
                "Очень важно": self.colors["DangerColor"],
            }.get(priority, self.TxtColor)
            details.append(self._task_badge(
                ft.Icons.FLAG_OUTLINED, priority, priority_color,
            ))
        if attachments and not self.phone:
            details.append(attachment_controls(self.libs, attachments))
        if details:
            task_content = ft.Column(
                controls=[taskW, *details],
                spacing=3 if self.phone else 6,
                tight=True,
            )
        else:
            task_content = taskW

        """Buttons"""
        checkbox = None
        if show_checkbox:
            checkbox = ft.Checkbox(
                value=status,
                tooltip="Отметить выполнение",
            )
            checkbox.on_change = lambda e: self.on_change_checkbox(
                e, id_task, checkbox.value, row_with_task, taskW
            )

        def menu_item(label, icon, on_click=None):
            return ft.PopupMenuItem(
                content=label,
                icon=ft.Icon(icon, size=18, color=self.libs.FletIconColor),
                label_text_style=ft.TextStyle(
                    size=self.libs.text_size(14), color=self.TxtColor,
                ),
                on_click=on_click,
            )

        redact = menu_item("Редактировать", ft.Icons.EDIT_ROUNDED)
        delete = menu_item("Удалить", ft.Icons.DELETE_ROUNDED)
        items = [redact, menu_item("Скопировать", ft.Icons.CONTENT_COPY_ROUNDED, on_copy)]
        if show_checkbox:
            items.append(menu_item("Сделать повторяющимися", ft.Icons.REPEAT_ROUNDED, on_repeat))
        items.append(delete)
        actions = [ft.PopupMenuButton(
            icon=ft.Icons.MORE_VERT,
            icon_color=self.libs.FletIconColor,
            tooltip="Действия с делом" if show_checkbox else "Действия с заметкой",
            items=items,
        )]

        cont_with_actions = ft.Container(
            content=ft.Row(actions, spacing=0, tight=True),
        )

        """Возвращение"""
        text_container = ft.Container(content=task_content, expand=True)
        row_controls = (
            [*([checkbox] if checkbox is not None else []), text_container, cont_with_actions]
            if self.phone else
            [cont_with_actions, *([checkbox] if checkbox is not None else []), text_container]
        )
        if attachments and self.phone:
            # Share the whole card body with filenames so their buttons line up
            # at the right edge, below the task actions.
            body = ft.Column([
                ft.Row(
                    [text_container, cont_with_actions],
                    spacing=4 if self.phone else 10,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                attachment_controls(self.libs, attachments),
            ], spacing=3 if self.phone else 6, tight=True, expand=True)
            row_controls = [*([checkbox] if checkbox is not None else []), body]
        row_with_task = SurfaceHost(
            content=ft.Row(
                controls=row_controls,
                spacing=4 if self.phone else 10,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            bgcolor=self.ContBgColor,
            border=ft.Border.all(1, self.colors["SoftBorderColor"]),
            border_radius=14,
            padding=ft.Padding.symmetric(
                horizontal=6 if self.phone else 12,
                vertical=6 if self.phone else 12,
            ),
            opacity=0.6 if status else 1,
            animate_opacity=160,
        )
        row_with_task._nd_glass_card = True
        row_with_task._nd_reorder_area = text_container
        return [row_with_task, delete, redact, taskW, checkbox]

    def _task_badge(self, icon, text, color):
        return ft.Container(
            content=ft.Row([
                ft.Icon(icon, size=13, color=color),
                ft.Text(text, size=self.libs.text_size(12), color=color),
            ], spacing=5, tight=True, wrap=True),
            bgcolor=ft.Colors.with_opacity(0.08, str(color).split(",")[0]),
            border_radius=6,
            padding=ft.Padding.symmetric(horizontal=7, vertical=3),
        )

    def on_change_checkbox(self, e, id_task, status, row_with_task, taskW, *, update=True):
        """Функция для сохранения изменений в файле после изменения статуса,
        а также визуального отображения выполненного дела:
        строка становится полупрозрачной, а текст — зачёркнутым."""
        self.back.redact_statusB(id_task, status)
        self.cloud.alg_for_redact()

        row_with_task.opacity = 0.6 if status else 1
        taskW.style = (
            ft.TextStyle(decoration=ft.TextDecoration.LINE_THROUGH)
            if status
            else None
        )
        if update:
            row_with_task.update()

    def open_warn_dialog(self, content, page):
        """Функция для открытия диалога-предупреждения перед
        удалением, добавляется для удалить всё, возможно
        добавлю для обычного удаления.

        Показывается как настоящий AlertDialog поверх текущей страницы,
        а не как контейнер для отдельного View."""

        def cancel(e=None):
            page.pop_dialog()

        def ok(e=None):
            page.pop_dialog()

        cancel_button = ft.Button(
            "Нет",
            style=ft.ButtonStyle(
                shape=ft.RoundedRectangleBorder(radius=5),
                padding=8,
                color=self.TxtColor,
            ),
            on_click=cancel,
            bgcolor=self.BtnColor,
        )

        yes_button = ft.Button(
            "Да",
            style=ft.ButtonStyle(
                shape=ft.RoundedRectangleBorder(radius=5),
                padding=8,
                color=self.TxtColor,
            ),
            on_click=ok,
            bgcolor=self.BtnColor,
        )

        dialog = ft.AlertDialog(
            modal=True,
            bgcolor=self.ContBgColor,
            shape=ft.RoundedRectangleBorder(radius=10),
            content=ft.Text(
                content,
                size=self.libs.text_size(16),
                weight=ft.FontWeight.W_500,
                color=self.TxtColor,
            ),
            actions=[yes_button, cancel_button],
            actions_alignment=ft.MainAxisAlignment.END,
        )

        page.show_dialog(self.libs.prepare(dialog))

        return dialog, yes_button, cancel_button

    def cont_auth_accounts(self, login_cmd):
        """Создание контейнера со всеми
        авторизованными аккаунтами"""
        widgets_4_main = []

        def log_out(l, p, r):
            main.content.controls.remove(r)
            self.back2.exit_from_auth_accounts(l, p)

        # Backend2 на сайте хранит список аккаунтов в browser storage, а не
        # в self.user_data (это Path только для ПК/Android). Используем его
        # единый публичный API — он работает в обоих режимах.
        for item in self.back2.read_accounts():
            log = item[0]
            pas = item[1]

            if not self.back2.check_accounts(log, pas):
                log_form = self.back.auto_add_new_string(log)

                btnIN = self.libs.create_style_button(f'Перейти в {log_form}')
                btnIN.on_click = lambda _, l=log, p=pas: login_cmd(l, p)

                btnOUT = self.libs.build_button_with_image('logout',f'Выйти из {log_form}',
                                                           size=36)

                row = ft.Row(
                    [btnIN, btnOUT],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                )

                btnOUT.on_click = lambda _, l=log, p=pas, r=row: log_out(l, p, r)

                widgets_4_main.append(row)

        main = self.libs.create_style_cont(
            widgets_4_main,
            width=self.width_dialogs*0.9
        )

        return main

    def build_shared_groups_tile(self, page):
        name = ft.TextField(label="Название общей группы", color=self.TxtColor)
        password = ft.TextField(label="Пароль общей группы", password=True,
                                can_reveal_password=True, color=self.TxtColor)
        status = ft.Text("Подключайте общие группы дел и заметок по названию и паролю.", color=self.TxtColor,
                         size=self.libs.text_size(13))
        memberships = ft.Column(spacing=8)
        connect = self.libs.create_style_button("Подключить общую группу", primary=True)
        progress = ft.ProgressRing(width=20, height=20, visible=False)

        def refresh_memberships():
            groups = [g for g in self.back.get_groups() if g.get("is_shared")]
            memberships.controls = [ft.Row([
                ft.Icon(ft.Icons.LINK_ROUNDED, color=self.libs.FletIconColor, size=20),
                ft.Text(g.get("shared_name") or g["name"], expand=True,
                        color=self.TxtColor, size=self.libs.text_size(15)),
            ]) for g in groups] or [ft.Text("Вы пока не подключены к общим группам.",
                                           color=self.TxtColor, size=self.libs.text_size(13))]

        async def join(_):
            if connect.disabled:
                return
            connect.disabled = name.disabled = password.disabled = True
            progress.visible = True
            page.update()
            try:
                await asyncio.to_thread(self.back.connect_shared_group, name.value or "", password.value or "")
                password.value = name.value = ""
                refresh_memberships()
                status.value = "Общая группа подключена. Она доступна в списке групп."
                status.color = self.TxtColor
            except ValueError as exc:
                status.value = str(exc)
                status.color = ft.Colors.RED
            except Exception:
                status.value = "Не удалось подключить группу. Проверьте подключение к Dropbox и повторите."
                status.color = ft.Colors.RED
            finally:
                connect.disabled = name.disabled = password.disabled = False
                progress.visible = False
            page.update()

        connect.on_click = password.on_submit = join
        refresh_memberships()
        return self.libs.create_style_expansion_category(
            ft.Icons.LINK_ROUNDED, "Общие группы",
            [ft.Column(
                [memberships, name, password, ft.Row([connect, progress], wrap=True), status],
                spacing=14,
                tight=True,
                horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
            )],
            padding=ft.Padding.symmetric(horizontal=20, vertical=16),
        )

    def build_widgets_for_login(self, page, function_for_update, login_cmd):
        """Постройка виджетов для диалога
        с авторизацией/регистрацией"""
        cont_title = self.libs.create_style_header("Авторизация")

        lblT = ft.Text(
            " Вход/Регистрация", size=self.libs.text_size(18), weight=ft.FontWeight.W_900, color=self.TxtColor
        )

        lbl1 = ft.Text("Введите логин:", size=self.libs.text_size(15), color=self.TxtColor)

        ent_with_login = ft.TextField(hint_text="Логин", color=self.TxtColor)

        lbl2 = ft.Text("Введите пароль:", size=self.libs.text_size(15), color=self.TxtColor)

        ent_with_password = ft.TextField(hint_text="Пароль", color=self.TxtColor, 
                                         password=True, can_reveal_password=True)

        texts_for_login = self.cloud.read_user_data()

        LlblT0 = ft.Text(
            " Управление аккаунтом",
            size=self.libs.text_size(18),
            weight=ft.FontWeight.W_900,
            color=self.TxtColor,

        )

        LlblT = ft.Text(texts_for_login["Start text"], size=self.libs.text_size(16), color=self.TxtColor)

        LlblL = ft.Text(texts_for_login["Login"], size=self.libs.text_size(16), color=self.TxtColor)

        LlblP = ft.Text(texts_for_login["Password"], size=self.libs.text_size(16), color=self.TxtColor)

        btn_logout = self.libs.create_style_button(
            "Выйти из аккаунта"
        )

        btn_logout.on_click = lambda: (
                self.cloud.leave_from_account(),
                self.libs.open_dialog("Авторизация", "Вы успешно вышли из аккаунта", page),
                function_for_update(),
            )

        btn_delete_account = self.libs.create_style_button(
            'Удалить аккаунт'
        )

        btn_delete_account.on_click = lambda: (
                self.cloud.delete_account(),
                self.libs.open_dialog("Авторизация", "Вы успешно удалили аккаунт", page),
                function_for_update(),
            )

        if self.cloud.check_user_data():
            btn_logout.visible = True
            btn_delete_account.visible = True
        else:
            btn_logout.visible = False
            btn_delete_account.visible = False

        cont_with_account = ft.Container(
            content=ft.Row([btn_logout, btn_delete_account]),
        )

        btn_login = self.libs.create_style_button(
            'Войти', primary=True
        )

        btn_for_register = self.libs.create_style_button(
            'Зарегистрироваться'
        )

        btn_cancel = self.libs.create_style_button(
            'Назад'
        )

        cont_with_auth = ft.Container(
            content=ft.Row([btn_login, btn_for_register]),
        )

        auth_accounts_tile = self.libs.create_style_expansion_category(
            ft.Icons.ACCOUNT_CIRCLE_ROUNDED,
            'Авторизованные аккаунты',
            [self.cont_auth_accounts(login_cmd)],
            padding=4
        )

        cont_main = self.libs.create_style_cont(
                [
                    lblT,
                    lbl1,
                    ent_with_login,
                    lbl2,
                    ent_with_password,
                    cont_with_auth,
                    auth_accounts_tile,
                    self.build_shared_groups_tile(page),
                    LlblT0,
                    LlblT,
                    LlblL,
                    LlblP,
                    cont_with_account,
                    btn_cancel,
                ]
        )
        itog = {
            "Main_cont": cont_main,
            "Header_cont": cont_title,
            "Login": ent_with_login,
            "Password": ent_with_password,
            "Cancel": btn_cancel,
            "Login_act": btn_login,
            "Register_act": btn_for_register,
        }
        return itog
